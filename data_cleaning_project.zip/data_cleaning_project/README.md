# Data Cleaning Project
This project includes scripts and notebooks for setting up the environment, organizing your data, and performing common cleaning tasks.

## Folder Structure

## Setup
[Setup instructions are provided for both macOS/Linux and Windows:]

### macOS/Linux

Run the shell script to automatically create and activate a conda environment named `data_cleaning` and install all required packages:
```sh
source create_conda_env.sh
```
This will:
- Create a conda environment named `data_cleaning` (Python 3.12)
- Activate the environment
- Install all packages from `requirements.txt`

### Windows

Run the batch file to automatically create and activate a conda environment named `data_cleaning` and install all required packages:
```bat
create_conda_env.bat
```
This will:
- Create a conda environment named `data_cleaning` (Python 3.12)
- Activate the environment
- Install all packages from `requirements.txt`


[DGCMIO (R) – Data Cleaning & Clinical Analytics Project]

## Overview
This project provides a reproducible workflow for profiling, cleaning, and mapping clinical data, including vitals and medications. The workflow is implemented in Python and Jupyter Notebooks, with outputs suitable for further clinical and NLP analysis.

## Setup
1. Navigate to the project folder:
   ```sh
   cd data_cleaning_project
   ```
2. **Install dependencies**:
   ```sh
   pip install -r requirements.txt
   ```
   Main libraries used:
   - pandas
   - numpy
   - matplotlib
   - seaborn
   - pytest
   - jupyter

3. **Project Structure:**
   - `notebooks/`: Main workflow and code for jupyter notebook
   - `tests/`: Data-quality tests (using pytest)
   - `data/raw/`: Raw input data divided into ed and medication
   - `data/output/`: Cleaned and processed outputs

## How to Run
1. **Run the Jupyter Notebook:**
   - Open `notebooks/data_cleaning_setup.ipynb` in JupyterLab or VS Code.
   - Execute cells sequentially to profile, clean, and map data.
   - Outputs (cleaned files, mapping tables, analytics) are saved in `data/output/`.

2. **Run Automated Tests:**
   - From the project root, run:
     ```sh
     PYTHONPATH=. pytest tests/test_data_quality.py
     ```
   - Tests validate unit conversions, physiological limits, duplicate removal, and null ID handling.

## Design Choices
- **Data Cleaning Logic:**
  - Unit conversions and physiological limits are based on published clinical ranges (see notebook for references).
  - Duplicate rows and null IDs are removed for data integrity.
  - Medication mapping uses RxNorm (via NDC and string matching) for standardization.
- **Modular Functions:**
  - Cleaning and mapping logic is encapsulated in reusable Python functions.
- **Automated Testing:**
  - Pytest is used to ensure data-quality rules are enforced and reproducible.
- **Open-Source Libraries:**
  - pandas, numpy, matplotlib, seaborn, pytest

## Citations
- pandas: https://pandas.pydata.org/
- numpy: https://numpy.org/
- matplotlib: https://matplotlib.org/
- seaborn: https://seaborn.pydata.org/
- pytest: https://pytest.org/

## Notes
- Ensure raw data files are placed in the correct folders (`data/raw/ed`, `data/raw/medication_list`).
- All outputs are written to `data/output/`.