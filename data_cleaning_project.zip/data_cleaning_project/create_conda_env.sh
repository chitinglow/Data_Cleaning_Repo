#!/bin/bash
# Script to create and activate a conda environment for the data cleaning project
ENV_NAME="data_cleaning"

conda create -y -n $ENV_NAME python=3.12
echo "Activating environment: $ENV_NAME"
source $(conda info --base)/etc/profile.d/conda.sh
conda activate $ENV_NAME
echo "Installing required packages from requirements.txt"
pip install -r requirements.txt
echo "Setup complete. You can now run Jupyter or pytest as described in the README."
