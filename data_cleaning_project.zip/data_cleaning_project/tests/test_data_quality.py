import pandas as pd
import numpy as np
import pytest

from notebooks.data_cleaning import (clean_vitals_physio, clean_generic_physio)

def test_clean_vitals_physio_unit_conversion():
    df = pd.DataFrame({'temperature': [100, 37, 42]})
    cleaned = clean_vitals_physio(df)
    # 100°F should be converted to ~37.8°C
    assert np.isclose(cleaned['temperature'].iloc[0], (100-32)*5/9)
    # 37°C should remain unchanged
    assert cleaned['temperature'].iloc[1] == 37
    # 42°C should be set to NaN (physiologically impossible)
    assert np.isnan(cleaned['temperature'].iloc[2])

def test_clean_vitals_physio_physio_limits():
    df = pd.DataFrame({
        'temperature': [36, 50],
        'systolic': [120, 500],
        'diastolic': [80, 500],
        'heartrate': [80, 300],
        'respiratoryrate': [20, 100],
        'spo2': [98, 30]
    })
    cleaned = clean_vitals_physio(df)
    assert np.isnan(cleaned['temperature'].iloc[1])
    assert np.isnan(cleaned['systolic'].iloc[1])
    assert np.isnan(cleaned['diastolic'].iloc[1])
    assert np.isnan(cleaned['heartrate'].iloc[1])
    assert np.isnan(cleaned['respiratoryrate'].iloc[1])
    assert np.isnan(cleaned['spo2'].iloc[1])

def test_clean_generic_physio_duplicates_and_nulls():
    df = pd.DataFrame({
        'subject_id': [1, 1, 2, None],
        'value': [10, 10, 20, 30]
    })
    cleaned = clean_generic_physio(df)
    # Should remove duplicate and null subject_id
    assert len(cleaned) == 2
    assert cleaned['subject_id'].isnull().sum() == 0
    assert set(cleaned['subject_id']) == {1, 2}
