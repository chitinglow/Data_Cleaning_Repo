# %% [markdown]
# # DGCMIO (R) – Technical Assessment
# 

# %%
import pandas as pd
import numpy as np
import re
import json
import os
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import timedelta
from pathlib import Path

os.chdir('/Users/chilow/Desktop/data_cleaning_project')

def read_all_gzipped_csv_in_folder(folder_path):
    """
    Reads all .csv.gz files in the given folder and returns a dictionary of DataFrames.
    """
    folder = Path(folder_path)
    dataframes = {}
    for file in folder.glob('*.csv.gz'):
        var_name = file.stem.replace('.csv', '')
        try:
            df = pd.read_csv(file, compression='gzip')
            dataframes[var_name] = df
            print(f"Loaded {file.name} into variable '{var_name}' (shape: {df.shape})")
        except Exception as e:
            print(f"Error reading {file}: {e}")
    return dataframes

# Read all files in ed folder
ed_dataframes = read_all_gzipped_csv_in_folder('data/raw/ed')

# To access each DataFrame:
diagnosis_df = ed_dataframes['diagnosis']
edstays_df = ed_dataframes['edstays']
medrecon_df = ed_dataframes['medrecon']
pyxis_df = ed_dataframes['pyxis']
triage_df = ed_dataframes['triage']
vital_df = ed_dataframes['vitalsign']

# %% [markdown]
# ## Part A – Data Quality & Normalisation 
# A.1 Profile the vitals and medication files

# %%
# Generate descriptive statistics for vitalsign
vitalsign_profile = vital_df.describe()

# Generate descriptive statistics for medrecon
medrecon_profile = medrecon_df.describe()

# Create an Excel writer object and save to data/output folder
output_filename = 'data/output/A1_dataset_profiles.xlsx'
with pd.ExcelWriter(output_filename) as writer:
    vitalsign_profile.to_excel(writer, sheet_name='vitalsign_profile')
    medrecon_profile.to_excel(writer, sheet_name='medrecon_profile')

# %% [markdown]
# A.2 Detect & correct: unit errors (°F↔°C, mmHg↔kPa), physiologically impossible values, duplicate rows, null IDs.
# 

# %%
vitalsign_profile

# %%
medrecon_profile

# %% [markdown]
# ## Assumption for physiological impossible values
# ### Temparature (https://en.wikipedia.org/wiki/Human_body_temperature)
# * Hypothermian (<35)
# * Normal (36.5 - 37.5)
# * Fever (>37.5 - 41)
# 
# Any value >41 degree will threat as F and convert to Celcius
# 
# ### Blood pressure (https://www.ncbi.nlm.nih.gov/books/NBK9633/table/A32/)
# * Normal (SBP <120 and DBP <80)
# * Prehypertension (120 - 139 or 80 - 89)
# * Stage 1 (140 - 159 or 90 - 99)
# * Stage 2 (>=160 or > 100)
# 
# ### Heart Rate (https://www.healthline.com/health/dangerous-heart-rate#maximum-heart-rate)
# * use the normal range from 75 - 220
# 
# ### Respiraotry rate (https://emedicine.medscape.com/article/2172054-overview#a3)
# * using the range (12 - 60) due to no age given
# 
# ### Oxygen saturation (https://www.medicinenet.com/what_are_blood_oxygen_levels/article.htm)
# * Using range between 60 - 100 %

# %%
def clean_vitals_physio(df):
    df = df.copy()
    # Temperature: °F to °C if values > 41°C (likely °F)
    if 'temperature' in df.columns:
        temp = df['temperature']
        fahrenheit_mask = temp > 41
        df.loc[fahrenheit_mask, 'temperature'] = (temp[fahrenheit_mask] - 32) * 5/9
        # Set impossible values (<35 or >41°C) to NaN
        df.loc[(df['temperature'] < 35) | (df['temperature'] > 41), 'temperature'] = np.nan
    # Blood pressure: mmHg to kPa if values > 250 (likely mmHg)
    for bp_col in ['systolic', 'diastolic']:
        if bp_col in df.columns:
            bp = df[bp_col]
            mmhg_mask = bp > 250
            df.loc[mmhg_mask, bp_col] = bp[mmhg_mask] * 0.133322
            # Set impossible values (<40 or >300 mmHg/kPa) to NaN
            df.loc[(df[bp_col] < 40) | (df[bp_col] > 300), bp_col] = np.nan
    # Heart rate: physiologically impossible values outside range of 75-22
    if 'heartrate' in df.columns:
        df.loc[(df['heartrate'] < 75) | (df['heartrate'] > 220), 'heartrate'] = np.nan
    # Respiratory rate: physiologically impossible values outside range of 12-6
    if 'respiratoryrate' in df.columns:
        df.loc[(df['respiratoryrate'] < 12) | (df['respiratoryrate'] > 60), 'respiratoryrate'] = np.nan
    # Oxygen saturation: physiologically impossible values outside range of 60-100
    if 'spo2' in df.columns:
        df.loc[(df['spo2'] < 60) | (df['spo2'] > 100), 'spo2'] = np.nan
    return df

# for cleaning null IDs and duplicates
def clean_generic_physio(df):
    df = df.copy()
    df = df.drop_duplicates()
    id_col = None
    for possible_id in ['patient_id', 'id', 'subject_id', 'visit_id']:
        if possible_id in df.columns:
            id_col = possible_id
            break
    if id_col:
        df = df[df[id_col].notnull()]
    return df

# loop through each DataFrame and clean it
for name, df in ed_dataframes.items():
    if name == 'vitalsign':
        cleaned_df = clean_vitals_physio(df)
    else:
        cleaned_df = clean_generic_physio(df)
    # Save cleaned DataFrame to output folder with _cleaned suffix
    cleaned_path = f"data/output/{name}_cleaned.csv"
    cleaned_df.to_csv(cleaned_path, index=False)

# %%
# Load cleaned medication file
rxnconso_path = 'data/raw/medication_list/rxnorm_rxnconso.csv'
rxnsat_path = 'data/raw/medication_list/rxnorm_rxnsat.csv'

rxnconso_df = pd.read_csv(rxnconso_path)
rxnsat_df = pd.read_csv(rxnsat_path)


# Helper: Extract drug components (bonus)
def extract_drug_components(description):
    if pd.isna(description):
        return {'name': '', 'dose': None, 'route': None, 'form': None}
    desc = str(description).upper()
    dose_pattern = r'(\d+(?:\.\d+)?\s*(?:MG|ML|MCG|G|GRAM|%|UNIT|UNITS|IU|MEQ)(?:/\w+)?)'
    dose_matches = re.findall(dose_pattern, desc)
    dose = ' / '.join(dose_matches) if dose_matches else None
    routes = ['ORAL', 'INTRAVENOUS', 'IV', 'IM', 'INTRAMUSCULAR', 'TOPICAL', 'INHALATION', 'SUBLINGUAL', 'RECTAL', 'NASAL', 'SUBCUTANEOUS', 'SC']
    route = next((r for r in routes if r in desc), None)
    forms = ['TABLET', 'CAPSULE', 'INJECTION', 'CREAM', 'OINTMENT', 'SOLUTION', 'SUSPENSION', 'POWDER', 'SYRUP', 'PATCH', 'SPRAY', 'DROPS']
    form = next((f for f in forms if f in desc), None)
    name_pattern = r'^([A-Za-z][A-Za-z\s]*?)(?:\s+\d|\s+\[|\s+\(|$)'
    name_match = re.match(name_pattern, description.strip())
    drug_name = name_match.group(1).strip() if name_match else description.split()[0] if description.split() else ''
    return {'name': drug_name, 'dose': dose, 'route': route, 'form': form}


# Prepare RxNorm lookup (SAB='RXNORM', preferred terms)
rxnorm_lookup = rxnconso_df[(rxnconso_df['sab'] == 'RXNORM') & (rxnconso_df['tty'].isin(['SCD', 'SBD', 'GPCK', 'BPCK', 'IN', 'PIN']))].copy()


# Map medications to RxNorm
mapping_results = []
for idx, row in medrecon_df.iterrows():
    subject_id = row.get('subject_id', '')
    charttime = row.get('charttime', '')
    drug_desc = str(row.get('name', '')).strip()
    ndc = str(row.get('ndc', ''))
    if not drug_desc or drug_desc.lower() in ['', 'nan', 'none']:
        continue
    rxnorm_id = None
    matched_desc = None
    # If NDC is present, try to map via rxnsat
    if ndc and ndc != '0' and not pd.isna(ndc):
        ndc_matches = rxnsat_df[(rxnsat_df['atn'].str.upper() == 'NDC') & (rxnsat_df['atv'].astype(str) == ndc)]
        if not ndc_matches.empty:
            rxcui = ndc_matches.iloc[0]['rxcui']
            rxnorm_row = rxnorm_lookup[rxnorm_lookup['rxcui'] == rxcui]
            if not rxnorm_row.empty:
                rxnorm_id = rxcui
                matched_desc = rxnorm_row.iloc[0]['str']
    # If no NDC match, try exact/partial string match
    if not rxnorm_id:
        exact_matches = rxnorm_lookup[rxnorm_lookup['str'].str.upper() == drug_desc.upper()]
        if not exact_matches.empty:
            rxnorm_id = exact_matches.iloc[0]['rxcui']
            matched_desc = exact_matches.iloc[0]['str']
        else:
            first_word = re.escape(drug_desc.split()[0])
            if len(first_word) > 2:
                partial_matches = rxnorm_lookup[rxnorm_lookup['str'].str.contains(first_word, case=False, na=False)]
                if not partial_matches.empty:
                    rxnorm_id = partial_matches.iloc[0]['rxcui']
                    matched_desc = partial_matches.iloc[0]['str']
    # Extract drug components
    extraction_desc = matched_desc if matched_desc else drug_desc
    drug_info = extract_drug_components(extraction_desc)
    mapping_results.append({
        'subject_id': subject_id,
        'charttime': charttime,
        'rxnorm_id': rxnorm_id,
        'drug_description': matched_desc if matched_desc else drug_desc,
        'drug_name': drug_info['name'],
        'dose': drug_info['dose'],
        'route': drug_info['route'],
        'form': drug_info['form']
    })


# Output tidy table
output_df = pd.DataFrame(mapping_results)
output_path = 'data/output/medication_rxnorm_mapping.csv'
output_df.to_csv(output_path, index=False)
print(f"✅ Output saved to: {output_path}")
print(f"Total medications processed: {len(output_df)}")
print(f"Mapped to RxNorm: {output_df['rxnorm_id'].notna().sum()}")
print(f"Success rate: {(output_df['rxnorm_id'].notna().sum() / len(output_df) * 100):.1f}%")
print(output_df.head(10))

# %% [markdown]
# # Part B – Clinical NLP / Entity Extraction (≈ 30 %)
# ## B.1 Extract the following as JSON lines, one visit (stay) per line:
# 
# Merge the traige with edstays to get admission date and duration
# Key to merge using subject_id and stay_id

# %%
df_merge = pd.merge(triage_df, edstays_df, on=['subject_id', 'stay_id'], how='left')
df_merge['intime'] = pd.to_datetime(df_merge['intime'], errors='coerce')
df_merge['outtime'] = pd.to_datetime(df_merge['outtime'], errors='coerce')

df_merge['duration'] = (df_merge['outtime'] - df_merge['intime']).dt.total_seconds()

# Function to convert seconds to ISO 8601 duration format
def to_iso8601_duration(seconds):
    if pd.isna(seconds):
        return None
    seconds = int(seconds)
    if seconds < 0:
        return None

    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)

    duration_parts = []
    if days > 0:
        duration_parts.append(f"{days}D")
    if hours > 0:
        duration_parts.append(f"{hours}H")
    if minutes > 0:
        duration_parts.append(f"{minutes}M")
    if seconds > 0:
        duration_parts.append(f"{seconds}S")

    if not duration_parts:
        return "PT0S" # If duration is 0, represent as PT0S
    return "P" + "".join(duration_parts)

df_merge['duration_iso8601'] = df_merge['duration'].apply(to_iso8601_duration)

# %%
# Group diagnoses by subject_id and stay_id
diagnoses_grouped = diagnosis_df.groupby(['subject_id', 'stay_id']).apply(
    lambda x: x[['icd_code', 'icd_title']].to_dict(orient='records')
).reset_index(name='diagnoses')

# using name from the medrecon and pyxis DataFrames
medications_medrecon_grouped = medrecon_df.groupby(['subject_id', 'stay_id']).apply(
    lambda x: x['name'].tolist()
).reset_index(name='home_medication_names_medrecon')

medications_pyxis_grouped = pyxis_df.groupby(['subject_id', 'stay_id']).apply(
    lambda x: x['name'].tolist()
).reset_index(name='home_medication_names_pyxis')


# Combine medication lists from medrecon and pyxis
all_medications_grouped = medications_medrecon_grouped
# Merge with pyxis, keeping both if they exist, then combine
all_medications_grouped = pd.merge(all_medications_grouped, medications_pyxis_grouped,
                                   on=['subject_id', 'stay_id'], how='outer')

def combine_med_lists(row):
    meds = []
    if isinstance(row['home_medication_names_medrecon'], list):
        meds.extend(row['home_medication_names_medrecon'])
    if isinstance(row['home_medication_names_pyxis'], list):
        meds.extend(row['home_medication_names_pyxis'])
    return list(set(meds)) # Use set to get unique medications

all_medications_grouped['home_medication'] = all_medications_grouped.apply(combine_med_lists, axis=1)
# Drop the intermediate columns
all_medications_grouped.drop(columns=['home_medication_names_medrecon', 'home_medication_names_pyxis'], inplace=True)


# Final merge for JSON output
df_final = pd.merge(df_merge, diagnoses_grouped, on=['subject_id', 'stay_id'], how='left')
df_final = pd.merge(df_final, all_medications_grouped, on=['subject_id', 'stay_id'], how='left')


# Select and format columns for JSON
json_output_list = []
for index, row in df_final.iterrows():
    entry = {
        "subject_id": row['subject_id'],
        "Admission_date": row['intime'].strftime('%Y-%m-%d %H:%M:%S') if pd.notna(row['intime']) else None,
        "Duration": row['duration_iso8601'],
        "Chief_complaint": row['chiefcomplaint'] if pd.notna(row['chiefcomplaint']) else None,
        "Diagnoses": row['diagnoses'] if isinstance(row['diagnoses'], list) else [],
        "Home_medication": row['home_medication'] if isinstance(row['home_medication'], list) else []
    }
    json_output_list.append(entry)

# Save JSON lines to a file
output_json_filename = 'data/output/B1_visit_data.jsonl'
with open(output_json_filename, 'w') as f:
    for entry in json_output_list:
        f.write(json.dumps(entry) + '\n')


# %% [markdown]
# ## B.2 Post NLP analytics

# %%
# 1. What are the 3 most common complaints?
common_complaints = triage_df['chiefcomplaint'].dropna().str.lower().value_counts()
top_3_complaints = common_complaints.head(3)

print(top_3_complaints)

# %%
# 2. What are the 3 most common ICD diagnoses?
common_diagnoses = diagnosis_df.groupby(['icd_code', 'icd_title']).size().reset_index(name='count')
common_diagnoses = common_diagnoses.sort_values(by='count', ascending=False)
top_3_diagnoses = common_diagnoses.head(3)

print(top_3_diagnoses)


# %% [markdown]
# # Part C – Temporal Reasoning & Narrative
# 
# Merge arrival, vitals, first medication time, and disposition into a minute-resolution event log per visit.
# 
# ### C.1 SpO₂ < 94 %, (mild) hypoxia for ≥ 5 min

# %%
# convert datetime columns to datetime objects
edstays_df['intime'] = pd.to_datetime(edstays_df['intime'], errors='coerce')
edstays_df['outtime'] = pd.to_datetime(edstays_df['outtime'], errors='coerce') 
vital_df['charttime'] = pd.to_datetime(vital_df['charttime'], errors='coerce')
medrecon_df['charttime'] = pd.to_datetime(medrecon_df['charttime'], errors='coerce')

# list to hold data for each stay
minute_data_list = []

# loop through each stay in edstays_df
for index, stay_row in edstays_df.iterrows():
    subject_id = stay_row['subject_id']
    stay_id = stay_row['stay_id']
    intime = stay_row['intime']
    outtime = stay_row['outtime']

    # Define the 6-hour window from admission
    end_time_window = intime + timedelta(hours=6)

    # Filter vitals for this stay and window
    stay_vitals = vital_df[(vital_df['subject_id'] == subject_id) &
                           (vital_df['stay_id'] == stay_id) &
                           (vital_df['charttime'] >= intime) &
                           (vital_df['charttime'] <= end_time_window)].copy()

    # Find first medication time for this stay
    stay_meds = medrecon_df[(medrecon_df['subject_id'] == subject_id) &
                            (medrecon_df['stay_id'] == stay_id)]

    first_med_time = stay_meds['charttime'].min() if not stay_meds.empty else None
    
    # Create minute index
    full_minute_idx = pd.date_range(start=intime, end=end_time_window, freq='min')
    
    # Reindex and forward-fill vital signs
    vitals_to_ffill = ['temperature', 'heartrate', 'resprate', 'o2sat', 'sbp', 'dbp']
    stay_vitals_resampled = stay_vitals.set_index('charttime')[vitals_to_ffill].reindex(full_minute_idx)
    stay_vitals_resampled = stay_vitals_resampled.ffill()

    # Add identifying columns
    stay_vitals_resampled['subject_id'] = subject_id
    stay_vitals_resampled['stay_id'] = stay_id
    stay_vitals_resampled['charttime'] = stay_vitals_resampled.index
    stay_vitals_resampled['time_from_intime_minutes'] = (stay_vitals_resampled.index - intime).total_seconds() / 6
    stay_vitals_resampled['first_med_time'] = first_med_time
    stay_vitals_resampled['disposition_time'] = outtime

    # Identify C.1 SpO₂ < 94 % (mild) hypoxia for ≥ 5 min
    stay_vitals_resampled['is_hypoxia'] = stay_vitals_resampled['o2sat'] < 94
    stay_vitals_resampled['hypoxia_roll_sum'] = stay_vitals_resampled['is_hypoxia'].rolling(window=5, min_periods=5).sum()
    stay_vitals_resampled['hypoxia_episode'] = stay_vitals_resampled['hypoxia_roll_sum'] >= 5

    minute_data_list.append(stay_vitals_resampled)


# Combine all stays
if minute_data_list:
    df_minute_events = pd.concat(minute_data_list).reset_index(drop=True)
else:
    df_minute_events = pd.DataFrame()
    
print(df_minute_events[['subject_id','stay_id','charttime','o2sat','is_hypoxia','hypoxia_episode']].head(20))


# %% [markdown]
# ### C.2 SBP < 90 mmHg, hypotension for ≥ 5 min

# %%
df_minute_events['is_hypotension'] = df_minute_events['sbp'] < 90
df_minute_events['hypotension_roll_sum'] = df_minute_events['is_hypotension'].rolling(window=5, min_periods=5).sum()
df_minute_events['hypotension_episode'] = df_minute_events['hypotension_roll_sum'] >= 5

print(df_minute_events[['subject_id','stay_id','charttime','sbp','is_hypotension','hypotension_episode']].head(20))

# %% [markdown]
# ### C.3 For patients experiencing episodes above, draw a heat-map (first 6 h, bin = 10 min) showing % of visits experiencing either episode

# %%
df_minute_events['any_episode'] = df_minute_events['hypoxia_episode'] | df_minute_events['hypotension_episode']
visits_with_episodes = df_minute_events[df_minute_events['any_episode']].stay_id.unique()

if len(visits_with_episodes) == 0:
    print("No visits with hypoxia or hypotension episodes detected.")
else:
    # Filter to affected visits
    df_episodes = df_minute_events[df_minute_events['stay_id'].isin(visits_with_episodes)].copy()
    # Bin time into 10-min intervals
    bins = np.arange(0, 361, 10)
    labels = [f'{i}-{i+9}' for i in bins[:-1]]
    df_episodes['time_bin'] = pd.cut(df_episodes['time_from_intime_minutes'], bins=bins, right=False, labels=labels)
    # For each bin, % of affected visits with any episode in that bin
    heatmap_data = pd.DataFrame(index=labels, columns=['Percentage'])
    total_visits = len(visits_with_episodes)
    for bin_label in labels:
        stays_in_bin = df_episodes[(df_episodes['time_bin'] == bin_label) & (df_episodes['any_episode'])]['stay_id'].nunique()
        percentage = (stays_in_bin / total_visits) * 100 if total_visits > 0 else 0
        heatmap_data.loc[bin_label, 'Percentage'] = percentage
    heatmap_data['Percentage'] = pd.to_numeric(heatmap_data['Percentage'])
    # Plot heatmap
    plt.figure(figsize=(18, 2))
    sns.heatmap([heatmap_data['Percentage'].values], cmap='YlGnBu', annot=True, fmt='.1f', cbar_kws={'label': '% of Visits'})
    plt.title('Visits Experiencing Hypoxia or Hypotension (First 6h, 10-min bins)')
    plt.xlabel('Time Bin')
    plt.yticks([0], ['% Visits'])
    plt.xticks(np.arange(len(labels))+0.5, labels, rotation=90)
    plt.tight_layout()
    plt.show()


